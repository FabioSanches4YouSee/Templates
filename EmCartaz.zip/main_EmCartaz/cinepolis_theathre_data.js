(function(global) {
	// Defaults
	var baseURL= '',
		basePosterURL = '/',
		provider = 'ingresso.com';

	var config;
	var extraInfo = {rooms : {}, movies : {}};
	/**
	 * Fetch the text data that will be used by the templatew
	 * @param  {Function} callback Callback with err or with the fetched data
	 */
	function fetchTextData (callback) {
		if (config.provider === 'consciencia') {
			return conscienciaWebService('Get_Cinema_Programacao', null, callback);
		}

		var request = new XMLHttpRequest(),
			endpoint = config.baseURL += '/GRADE.TXT?t=' + Date.now(); // Cache-buster timestamp'

		request.open('GET', endpoint, true);
		request.onload = function() {
			if (this.status >= 200 && this.status < 400) {
				if (this.response.length > 0) {
					callback(null, this.response);
				} else {
					displayError('Empty response!');
					callback(204);
				}
			} else {
				displayError('XHR Status ' + this.status);
				callback('ERROR: Status ' + this.status);
			}
		};
		request.onerror = function() {
			displayError('XHR ERROR!');
			callback('ERROR: XHR ERROR!');
		};
		request.send();
	}

	/**
	 * Fetch data from Consciencia WebServices
	 * @param  {String}   serviceName	Name of the fetched service
	 * @param  {String}   id			Id~of the resource (null if N/A)
	 * @param  {Function} callback
	 */
	function conscienciaWebService(serviceName, id, callback) {
		var request = new XMLHttpRequest(),
			endpoint = config.baseURL;

		endpoint += '/WSCinema.ws/' + serviceName + '/';
		var queryObject = {
			autenticacao : {
				usuario : config.user,
				senha : config.password
			},
		};
		switch (serviceName) {
			case 'Get_Cinema_Programacao':
				var today = moment().format('YYYY-MM-DD');
				queryObject.getProg = {
					dataini: today,
					datafin: today,
					nao_env_ingr : true
				};
				break;
			case 'Get_Cinema_Filmes':
				queryObject.getFilmes = {
					idFilme: id
				};
				break;
			case 'Get_Cinema_Salas':
				queryObject.getSalas = {
					codSala : id
				};
				break;
		}
		endpoint += encodeURIComponent(JSON.stringify(queryObject));
		endpoint += '?t=' + Date.now(); // Cache-buster timestamp

		//DEV only
        // switch (serviceName) {
        //     case 'Get_Cinema_Programacao':
        //         endpoint = 'programacao.json';
        //         break;
        //     case 'Get_Cinema_Filmes':
        //         endpoint = 'filmes' + id + '.json';
        //         break;
        //     case 'Get_Cinema_Salas':
        //         endpoint = 'salas' + id + '.json';
        //         break;
        // }
		//

		request.open('GET', endpoint, true);
		request.timeout = 60 * 1000;
		request.onload = function() {
			if (this.status >= 200 && this.status < 400) {
				if (this.response.length > 0) {
					try{
						var data = JSON.parse(this.response);
						if (data['ReturnOf' + serviceName].ERROS.length > 0) {
							return callback(data['ReturnOf' + serviceName].ERROS);
						}
						callback(null, data);
					} catch (err) {
						return callback(err);
					}
				} else {
					displayError('Empty response!');
					callback(204);
				}
			} else {
				displayError('XHR Status ' + this.status);
				callback('ERROR: Status ' + this.status);
			}
		};
		request.ontimeout = function () {
			displayError('XHR TIMEOUT!');
			callback('ERROR: XHR TIMEOUT!');
		};
		request.onerror = function() {
			displayError('XHR ERROR!');
			callback('ERROR: XHR ERROR!');
		};
		request.send();
	}

	/**
	 * Receive the text data and parses it [INGRESSO.COM]
	 * @param  {String} textData Data as fetched
	 * @return {Object}          Parsed Data
	 */
	function parseIngressoTextData (textData) {
		var lines = textData.split(/\r?\n/),
			theatres = {};
		lines.forEach(function(line, i) {
			if (line.length > 25) { //Ignores Date of last modification line
				// Room
				var room_number = line.substring(0, 2); // código identificador da sala
				if (!theatres[room_number]) {
					theatres[room_number] = {
						movies : [],
						sessions : [],
						isVIP : line.substring(84, 85) === 'S'
					};
				}

				// Movie
				var movieID = line.substring(2, 10); // código identificador do filme
				if (!containsMovie(theatres[room_number], movieID)) {
					var movieObj = {
						id : movieID,
						title : line.substring(15, 75).trim(), // nome do filme
						rating : line.substring(75, 77).trim(), // censura do filme
						is3D : line.substring(83, 84) === 'S', // indica se o filme é 3D (S) ou não (N)
						length : parseInt(line.substring(85, 88), 10), // duração do filme em minutos
						ancineID : line.substring(88, 104).trim() // código do filme na Ancine
					};
					movieObj.posterImage = config.basePosterURL + '/posters/' + movieObj.ancineID + '.jpg';
					theatres[room_number].movies.push(movieObj);
				}

				// Session
				theatres[room_number].sessions.push({
					time : global.moment(line.substring(10, 15), 'HH[h]mm'),
					is3D : line.substring(83, 84) === 'S', // indica se o filme é 3D (S) ou não (N)
					subtitled : line.substring(80, 81) === 'L',
					isSoldOut : line.substring(81, 82) === 'S',
					movieID : movieID
				});
			}
		});

		return theatres;
	}

	function containsMovie (theathre, movieID) {
		return theathre.movies.some(function(movie) {
			return movie.id === movieID;
		});
	}

	var displayError = console.error;

	function fetchMovieData(movieID, callback) {
		conscienciaWebService('Get_Cinema_Filmes', movieID, function(err, data) {
			if (err) {
				return callback(err);
			}
			extraInfo.movies[movieID] = data.ReturnOfGet_Cinema_Filmes.FILMES[0];
			callback();
		});
	}

	function fetchRoomData(roomID, callback) {
		conscienciaWebService('Get_Cinema_Salas', roomID, function(err, data) {
			if (err) {
				return callback(err);
			}
			extraInfo.rooms[roomID] = data.ReturnOfGet_Cinema_Salas.SALAS[0];
			callback();
		});
	}

	function parseConscienciaJSON(response, callback) {
		var roomIds = [];
		var movieIds = [];

		if (response.ReturnOfGet_Cinema_Programacao.PROGS.length === 0) {
			return callback('Empty programming!');
		}

		response.ReturnOfGet_Cinema_Programacao.PROGS.forEach(function(prog) {
			roomIds.push(prog.CODSALA);
			if (prog.IDFILMEPAI) {
				movieIds.push(prog.IDFILMEPAI);
			} else {
				movieIds.push(prog.IDFILME);
			}
		});

		roomIds = _.unique(roomIds);
		movieIds = _.unique(movieIds);

		async.waterfall([
			function fetchAllMovies(cb_waterfall) {
				async.eachSeries(movieIds, function(movieID, next) {
					if (!extraInfo.movies[movieID]) {
						fetchMovieData(movieID, next);
					} else {
						next();
					}
				}, cb_waterfall);
			},
			function fetchAllRooms(cb_waterfall) {
				async.eachSeries(roomIds, function(roomID, next) {
					if (!extraInfo.rooms[roomID]) {
						fetchRoomData(roomID, next);
					} else {
						next();
					}
				}, cb_waterfall);
			}
		], function(err) {
			if (err) {
				callback(err);
			} else {
				callback(null, conscienciaData(response));
			}
		});
	}

	function conscienciaData(response) {
		var theatres = {};

		response.ReturnOfGet_Cinema_Programacao.PROGS.forEach(function(prog) {
			// Room
			var roomData = extraInfo.rooms[prog.CODSALA];
			var room_number = global.leftPad(roomData.CODIGOINT, 2, '0');
			if (!theatres[room_number]) {
				theatres[room_number] = {
					movies : [],
					sessions : [],
					capacity : roomData.CAPACIDADE,
					isVIP : false, // TODO Integração
				};
			}

			// Movie
			var movieID = prog.IDFILMEPAI || prog.IDFILME; // código identificador do filme
			var movieData = extraInfo.movies[movieID];
			if (!containsMovie(theatres[room_number], movieID)) {
				var movieObj = {
					id : movieID,
					title : movieData.TITULO, // nome do filme
					rating : movieData.IDADE || 'L', // censura do filme
					// is3D : movieData.TRESD, // indica se o filme é 3D (S) ou não (N)
					length : movieData.DURACAO, // duração do filme em minutos
					genre : movieData.ESTILO_DESC // Gênero
				};
				if (movieData.INFOS.length > 0) {
					var info = _.find(movieData.INFOS, {TIPOINFO: 'CODANCINE'});
					if (info) {
						movieObj.ancineID = info.DESCRITIVO;
					}
				}
				if (movieObj.ancineID && movieObj.ancineID != '0') {
					movieObj.posterImage = config.basePosterURL + '/posters/' + movieObj.ancineID + '.jpg';
				}
				theatres[room_number].movies.push(movieObj);
			}

			// Session
			theatres[room_number].sessions.push({
				time : global.moment(prog.DATASESSAO),
				is3D : prog.TRESD, // indica se o filme é 3D (S) ou não (N)
				subtitled : prog.LEGENDADO,
				isSoldOut : prog.STATUS.match('ESGOTADO'),
				movieID : movieID
			});
		});

		return theatres;
	}
	global.cinepolis = {
		/**
		 * Returns the update data already parsed
		 * @param  {Function} callback (err,data)
		 */
		fetchData : function(_config, callback) {
			if (typeof _config === 'function') {
				callback = _config;
				_config = {};
			}
			config = _config;
			config.baseURL = config.baseURL || baseURL;
			config.basePosterURL = config.basePosterURL || basePosterURL;
			config.provider = config.provider || provider;
			if (config.provider === 'consciencia') {
				if (!config.user || !config.password) {
					return callback('No credentials for consciencia!');
				}
			}
			fetchTextData(function(err, data) {
				if (err) {
					callback(err);
				} else {
					if (config.provider === 'consciencia') {
						parseConscienciaJSON(data, callback);
					} else {
						// Ingresso.com
						callback(null, parseIngressoTextData(data));
					}
				}
			});
		}
	};
})(window);
